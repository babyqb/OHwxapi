local log = require("log")
local Api = require("coreApi")
local json = require("json")
local http = require("http")
-- CurrentWxid 当前操作的微信号 /funcName 欲调用LuaApi函数名 ／data  组装Json数据
function Api_LuaCaller(CurrentWxid, funcName, data)
    str = string.format("Api_LuaCaller FuncName %s\n", funcName)
    log.info("%s", str)
    local luaResp = nil
    local switch = {
        --发送消息接口
        ["SendMsg"] = function()
            return Api.SendMsgNew(CurrentWxid, data)
        end,
        ["SendAppMsg"] = function()
            return Api.SendAppMsg(CurrentWxid, data)
        end,
        ["SendVoice"] = function()
            return Api.SendVoice(CurrentWxid, data)
        end,
        ["SendImage"] = function()
            return Api.SendImage(CurrentWxid, data)
        end,
        ["SendCdnImage"] = function()
            return Api.SendCdnImage(CurrentWxid, data)
        end,
        ["SendEmoji"] = function()
            return Api.SendEmoji(CurrentWxid, data)
        end,
        ["GetContact"] = function()
            return Api.GetContact(CurrentWxid, data)
        end,
        ["DelChatRoomMber"] = function()
            return Api.DelChatRoomMber(CurrentWxid, data)
        end,
        ["CreateChatRoom"] = function()
            return Api.CreateChatRoom(CurrentWxid, data)
        end,
        ["GetIMQrcode"] = function()
            return Api.GetIMQrcode(CurrentWxid, data)
        end,
        ["InviteChatRoomMember"] = function()
            return Api.InviteChatRoomMember(CurrentWxid, data)
        end,
        ["VerifyUser"] = function()
            return Api.VerifyUser(CurrentWxid, data)
        end,
        ["GetA8Key"] = function()
            local baseResponse, resp = Api.GetA8Key(CurrentWxid, data)
            if baseResponse.Ret == 0 then
                return resp
            else
                return baseResponse
            end
        end,
        ["SnsPost"] = function()
            return Api.SnsPost(CurrentWxid, data)
        end,
        ["SnsComment"] = function()
            return Api.SnsComment(CurrentWxid, data)
        end,
        ["InitWxids"] = function()
            return Api.InitWxids(CurrentWxid, data)
        end,
        ["GetCdnDns"] = function()
            return Api.GetCdnDns(CurrentWxid)
        end,
        ["DownloadImage"] = function()
            return Api.DownloadImage(CurrentWxid, data)
        end,
        ["ConfirmTrans"] = function()
            return Api.ConfirmTrans(CurrentWxid, data)
        end,
        ["SearchContact"] = function()
            return Api.SearchContact(CurrentWxid, data)
        end,
        ["GetChatMemberInfo"] = function()
            return Api.GetChatMemberInfo(CurrentWxid, data)
        end,
        ["GetAppSession"] = function()
            return Api.GetAppSession(CurrentWxid)
        end,
        ["JSAuthLogin"] = function()
            return Api.JSAuthLogin(CurrentWxid, data)
        end,
        --添加定时任务
        ["AddCrons"] = function()
            return Api.AddCrons(data)
        end,
        --添加删除定时任务
        ["DelCrons"] = function()
            return Api.DelCrons(data.TaskID)
        end,
        --获取任务列表
        ["GetCrons"] = function()
            return Api.GetCrons()
        end
    }
    local fSwitch = switch[funcName] --switch func
    if fSwitch then --key exists
        luaResp = fSwitch() --do func
    else --key not found
        luaResp = {Ret = 1, Msg = string.format("Caller %s no exists %v", funcName, data)}
    end
    return luaResp
end

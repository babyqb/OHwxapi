local log = require("log")
local json = require("json")
local http = require("http")
local mysql = require("mysql")

function ReceiveWeChatMsg(CurrentWxid, data)
    log.info("%s", "\nReceiveWeChatMsg")

    str =
        string.format(
        "\nParseNewSync %s\nFromUserName %s ToUserName %s \nMsgType %d Status %d MsgId %d NewMsgId %d\nContent %s\nMsgSource %s\nPushContent %s\nActionUserName %s\nActionNickName %s\n",
        CurrentWxid,
        data.FromUserName,
        data.ToUserName,
        data.MsgType,
        data.Status,
        data.MsgId,
        data.NewMsgId,
        data.Content,
        data.MsgSource,
        data.PushContent,
        data.ActionUserName,
        data.ActionNickName
        -- PkgCodec.EncodeBase64(data.ImgBuf)
    )

    log.notice("From log.lua Log\n%s", str)
    return 1
end

function ReceiveWeChatEvents(CurrentWxid, data)
    log.info("%s", "\nReceiveWeChatEvents")
    str =
        string.format(
        "WeChatEvents %s\nFrom Msg \nWxid %s  \nChatRoom %s",
        data.EventName,
        CurrentWxid,
        data.FromUserName
    )

    log.notice("From log.Lua Log\n%s", str)

    if data.EventName == "ON_EVENT_SNS_NEW" then
       
        log.notice("Sns XML \n%s", data.SnsObject.ObjectDesc)
    end
    return 1
end

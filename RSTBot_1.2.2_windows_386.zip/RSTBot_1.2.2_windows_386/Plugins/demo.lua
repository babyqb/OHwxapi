local log = require("log")
local json = require("json")
local Api = require("coreApi")
local http = require("http")
local mysql = require("mysql")
--每个插件必须实现该事件
function ReceiveWeChatMsg(CurrentWxid, data)
    log.info("%s", "\nReceiveWeChatMsg")

    str =
        string.format(
        "\nParseNewSync %s\nFromUserName %s ToUserName %s \nMsgType %d Status %d MsgId %d\nContent %s\nMsgSource %s\nPushContent %s\nActionUserName %s\nActionNickName %s\n",
        CurrentWxid,
        data.FromUserName,
        data.ToUserName,
        data.MsgType,
        data.Status,
        data.MsgId,
        data.Content,
        data.MsgSource,
        data.PushContent,
        data.ActionUserName,
        data.ActionNickName
    )
    log.notice("From log.lua Log\n%s", str)

    if data.FromUserName == CurrentWxid then
        ToUserName = data.ToUserName --发给自己
    else
        ToUserName = data.FromUserName --发给群/好友
    end
    wxid = "" --在群内 触发消息的对象 消息发送者
    if string.find(ToUserName, "@chatroom") then
        wxid = data.ActionUserName
        if wxid == "" then
            wxid = data.FromUserName
        end
    else
        wxid = data.FromUserName
    end

    if data.Content == "TEST" then
        Api.SendImage(CurrentWxid, {ToUserName = ToUserName, ImagePath = "./running.png"}) --发送本地图片
        Sleep(1)
        --不要发送太快 睡眠1秒
        Api.SendImage(
            CurrentWxid,
            {
                ToUserName = ToUserName,
                ImageUrl = "http://gchat.qpic.cn/gchatpic_new/1348200269/757360354-2534335053-D3769D93A8943DF164CEC54D26677517/0?vuin=192801941&term=255&pictype=0"
            }
        ) --发送网络图片
        Sleep(1)
        --不要发送太快 睡眠1秒
        Api.SendVoice(CurrentWxid, {ToUserName = ToUserName, VoicePath = "./running.silk"}) --发送本地语音
        Sleep(1)
        --不要发送太快 睡眠1秒
        Api.SendVoice(CurrentWxid, {ToUserName = ToUserName, VoiceUrl = "http://running.silk"}) --发送网络语音
        GetUserNick(CurrentWxid, data)
        XmlStr =
            string.format(
            '<appmsg appid=""  sdkver="0"><title><![CDATA[[天啊]免VIP视频解析机器人[天啊]\n[Emm]指令如下[Emm]\n[旺柴]签到----每日签到🉐️积分\n[旺柴]信息----查询用户积分\n[旺柴]启用----群里启用\n[旺柴]停用----群里停用\n[机智]拉人进群都会🈶️积分奖励的哟\n[色]每次解析视频连接消耗2点积分仅支持腾讯爱奇艺芒果TV小程序解析(其他平台待完善)]]></title><des></des><action></action><type>57</type><showtype>0</showtype><soundtype>0</soundtype><mediatagname></mediatagname><messageext></messageext><messageaction></messageaction><content></content><contentattr>0</contentattr><url></url><lowurl></lowurl><dataurl></dataurl><lowdataurl></lowdataurl><songalbumurl></songalbumurl><songlyric></songlyric><appattach><totallen>0</totallen><attachid></attachid><emoticonmd5></emoticonmd5><fileext></fileext><cdnthumbaeskey></cdnthumbaeskey><aeskey></aeskey></appattach><extinfo></extinfo><sourceusername></sourceusername><sourcedisplayname></sourcedisplayname><thumburl></thumburl><md5></md5><statextstr></statextstr><directshare>0</directshare><refermsg><type>1</type><svrid>413279805977715132</svrid><fromusr></fromusr><chatusr></chatusr><displayname>消息来自:IPhone 12 X Max 1024GB📱</displayname><content>😄</content><msgsource></msgsource></refermsg></appmsg><fromusername></fromusername>',
            Nick
        )
        Sleep(1)
        --不要发送太快 睡眠1秒
        Api.SendAppMsg(CurrentWxid, {ToUserName = ToUserName, MsgType = 49, Content = XmlStr})
        -- 发送App消息
        Sleep(1)
        --不要发送太快 睡眠1秒
        Api.SendMsgNew(CurrentWxid, {ToUserName = ToUserName, MsgType = 1, Content = "你好", AtUsers = ""})
        --发送文字消息
        Sleep(1)
        --不要发送太快 睡眠1秒
        Api.SendMsgNew(CurrentWxid, {ToUserName = ToUserName, MsgType = 1, Content = "你好", AtUsers = "wxid_123"})
        --发送文字消息 @wxid_12312
        Sleep(1)
        --不要发送太快 睡眠1秒
        Api.SendCdnImage(
            CurrentWxid,
            {
                ToUserName = ToUserName,
                XmlStr = [[
            <msg>
                <img aeskey="7263bd84592aa8ac653b9e8ddc48f4eb" encryver="0" cdnthumbaeskey="7263bd84592aa8ac653b9e8ddc48f4eb" cdnthumburl="3059020100045230500201000204d26d70fe02032f4f5502045972512a02045e3952e7042b777875706c6f61645f31373635313336393533384063686174726f6f6d3231375f31353830383135303738020401051a020201000400" cdnthumblength="3109" cdnthumbheight="120" cdnthumbwidth="67" cdnmidheight="0" cdnmidwidth="0" cdnhdheight="0" cdnhdwidth="0" cdnmidimgurl="3059020100045230500201000204d26d70fe02032f4f5502045972512a02045e3952e7042b777875706c6f61645f31373635313336393533384063686174726f6f6d3231375f31353830383135303738020401051a020201000400" length="173545" md5="91eab7877dd055f914fb76ed865d367c" hevc_mid_size="97629" />
            </msg>]]
            }
        )
        --转发图片
        Sleep(1)
        --不要发送太快 睡眠1秒
        Api.SendEmoji(CurrentWxid, {ToUserName = ToUserName, EmojiMd5 = "aa567de4eb86b5d589d394ad489bcfd7"})
        --发送表情
        return 1
    end

    if data.MsgType == 1 and string.find(data.Content, "进群") then --邀请进群
        if string.find(ToUserName, "@") then
            return 1
        end
        baseResonse = Api.InviteChatRoomMember(CurrentWxid, "23306167883@chatroom", ToUserName)
        str =
            string.format("baseResonse.Ret %d baseResonse.ErrMsg %s Wxid %s", baseResonse.Ret, baseResonse.ErrMsg, wxid)
        log.notice("From Log\n%s", str)

        return 1
    end

    return 1
end
--每个插件必须实现该事件
function ReceiveWeChatEvents(CurrentWxid, data)
    log.info("%s", "\nReceiveWeChatEvents")
    str =
        string.format(
        "WeChatEvents %s\nFrom Msg \nWxid %s  \nChatRoom %s",
        data.EventName,
        CurrentWxid,
        data.FromUserName
    )

    log.notice("From log.Lua Log\n%s", str)

    if data.EventName == "ON_EVENT_FRIEND_REQ" then --处理好友请求信息
        baseResonse =
            Api.VerifyUser(
            CurrentWxid,
            {
                VerifyType = 3, --同意好友请求
                V1Username = "",
                V2Ticket = "",
                Content = "",
                Sence = 0,
                XmlStr = data.Content --会自动解析xml里的参数
            }
        )
        str =
            string.format("baseResonse.Ret %d baseResonse.ErrMsg %s Wxid %s", baseResonse.Ret, baseResonse.ErrMsg)
        log.notice("From ReceiveWeChatEvents Log\n%s", str)
    end
      if data.EventName == "ON_EVENT_SNS_EVENTS" then
        
        str =
            string.format(
            "SnsId %d ActionType %d 评论人Wxid %s 评论内容 %s",
            data.SnsEvents.Id,
            data.SnsEvents.SnsObjectType,
            data.SnsEvents.CurrentAction.FromUsername,
            data.SnsEvents.CurrentAction.Content
        )
        log.error("SNS Comment %s",str)
        return 1
    end
    if data.EventName == "ON_EVENT_CHATROOM_INVITE" then --处理群邀请信息
        if CurrentWxid == data.FromUserName then
            return 1
        end
        Url = data.Content:match([[<url><!%[CDATA%[(.+)%]%]></url>]])
        if Url == nil then
            Url = data.Content:match([[<url>(.+)</url]])
        end
        baseResonse, resp =
            Api.GetA8Key(
            CurrentWxid,
            {
                FromUserName = data.FromUserName,
                Sence = 2,
                Url = Url
            }
        )
        str =
            string.format(
            "baseResonse.Ret %d baseResonse.ErrMsg %s Url %s",
            baseResonse.Ret,
            baseResonse.ErrMsg,
            resp.Url
        )
        log.error("From ReceiveWeChatEvents Log\n%s", str)

        local response, error_message = http.request("GET", resp.Url)
        local html = response.body
        str = string.format("当前群人数 %s", html:match("(%d+)人"))
        log.info(" %s", str)
        response, error_message =
            http.request(
            "POST",
            resp.Url,
            {
                body = ""
            }
        )
        if error_message ~= nil then
            --resp Post weixin://jump/mainframe/19028215877@chatroom: unsupported protocol scheme "weixin
            log.notice("info   %s", "自动进群成功" .. error_message)
        else
            log.error(" resp %s", response.body)
        end
    end
    if data.EventName == "ON_EVENT_SNS_NEW" then
        log.notice("Sns XML \n%s", data.SnsObject.ObjectDesc)
    end
    if data.EventName == "ON_EVENT_CHATROOM_INVITE_OTHER" then --群邀请变的信息
        xmlStr =
            string.format(
            "ChatRoom %s 邀请人 %s 邀请人昵称 %s 被邀请人 %s 被邀请人昵称 %s",
            data.FromUserName,
            data.InviteUserName,
            data.InviteNickName,
            data.InvitedUserName,
            data.InvitedNickName
        )
        log.error("%s", xmlStr)
    end
    return 1
end
---用户自定义方法
--获取用户昵称等资料
function GetUserNick(CurrentWxid, data)
    Nick = data.ActionNickName
    if Nick == "" then
        UserTable =
            Api.GetContact(
            CurrentWxid,
            {
                ChatroomID = ToUserName,
                Wxid = {wxid}
            }
        )
        if UserTable ~= nil then
            Nick = UserTable[1].NickName
        end
    end

    str = string.format("ToUserName %s Wxid %s", ToUserName, wxid)

    log.notice("From log.Lua Log\n%s", str)
end
function Sleep(n)
    --log.notice("==========Sleep==========\n%d", n)
    local t0 = os.clock()
    while os.clock() - t0 <= n do
    end
    --log.notice("==========over Sleep==========\n%d", n)
end
